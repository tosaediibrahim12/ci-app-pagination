
    <h1>Hello world, my name is <?= $nama; ?>!</h1>

 
<?php

class User_model{
    private $nama = 'Tosaedi ibrahim';

    public function getUser(){
        return $this->nama;
    }
}